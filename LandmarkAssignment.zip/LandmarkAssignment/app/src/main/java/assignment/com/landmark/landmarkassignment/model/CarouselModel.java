package assignment.com.landmark.landmarkassignment.model;

import java.util.ArrayList;

/**
 * Created by chaitanya.ak on 13/09/16.
 */
public class CarouselModel {
  public String header;
  public ArrayList<CarouselItem> mCarouselItems;
}
