package assignment.com.landmark.landmarkassignment.adapter;

import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import assignment.com.landmark.landmarkassignment.R;
import assignment.com.landmark.landmarkassignment.connection.CustomRequestQueue;
import assignment.com.landmark.landmarkassignment.model.CarouselItem;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.NetworkImageView;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

/**
 * Created by chaitanya.ak on 13/09/16.
 */
public class CarouselPageAdapter extends PagerAdapter {

  private final WeakReference<OnCarouselItemSelected> mOnCarouselItemSelectedWeakReference;
  private final LayoutInflater mInfalter;
  private final ImageLoader mImageLoader;
  private ArrayList<CarouselItem> mCarouselItems;
  private OnCarouselItemSelected mListener;

  public CarouselPageAdapter(Context context,
      WeakReference<OnCarouselItemSelected> onCarouselItemSelectedWeakReference) {
    mInfalter = LayoutInflater.from(context);
    mOnCarouselItemSelectedWeakReference = onCarouselItemSelectedWeakReference;
    mCarouselItems = new ArrayList<>();
    mImageLoader = CustomRequestQueue.getInstance(context).getImageLoader();
  }

  @Override public int getCount() {
    return mCarouselItems.size() / 2;
  }

  @Override public boolean isViewFromObject(View view, Object object) {
    return view == object;
  }

  @Override public Object instantiateItem(ViewGroup container, final int pos) {

    final int position = pos * 2;
    View v = mInfalter.inflate(R.layout.item_cell, null);

    LinearLayout leftItem = (LinearLayout) v.findViewById(R.id.left_item);
    TextView tvLeft1 = (TextView) leftItem.findViewById(R.id.tvLeft);
    TextView tvRight1 = (TextView) leftItem.findViewById(R.id.tvRight);
    TextView tvItemType1 = (TextView) leftItem.findViewById(R.id.tvItemType);
    TextView tvItemName1 = (TextView) leftItem.findViewById(R.id.tvItemName);
    TextView tvItemPrice1 = (TextView) leftItem.findViewById(R.id.tvItemPrice);
    NetworkImageView ivItem1 = (NetworkImageView) leftItem.findViewById(R.id.ivItem);

    LinearLayout rightItem = (LinearLayout) v.findViewById(R.id.right_item);
    TextView tvLeft2 = (TextView) rightItem.findViewById(R.id.tvLeft);
    TextView tvRight2 = (TextView) rightItem.findViewById(R.id.tvRight);
    TextView tvItemType2 = (TextView) rightItem.findViewById(R.id.tvItemType);
    TextView tvItemName2 = (TextView) rightItem.findViewById(R.id.tvItemName);
    TextView tvItemPrice2 = (TextView) rightItem.findViewById(R.id.tvItemPrice);
    NetworkImageView ivItem2 = (NetworkImageView) rightItem.findViewById(R.id.ivItem);

    String leftBottom1 = mCarouselItems.get(position).getLeftBottom();

    if (!TextUtils.isEmpty(leftBottom1)) {
      tvLeft1.setText(leftBottom1);
    } else {
      tvLeft1.setVisibility(View.GONE);
    }

    String rightBottom1 = mCarouselItems.get(position).getRightBottom();

    if (!TextUtils.isEmpty(rightBottom1)) {
      tvRight1.setText(rightBottom1);
    } else {
      tvRight1.setVisibility(View.GONE);
    }

    tvItemType1.setText(mCarouselItems.get(position).titleCaps);
    tvItemName1.setText(mCarouselItems.get(position).titleName);
    tvItemPrice1.setText(mCarouselItems.get(position).price);
    ivItem1.setImageUrl(mCarouselItems.get(position).imgUrl, mImageLoader);

    int rightPosition = position + 1;
    if (rightPosition < mCarouselItems.size()) {
      String leftBottom2 = mCarouselItems.get(rightPosition).getLeftBottom();

      if (!TextUtils.isEmpty(leftBottom2)) {
        tvLeft2.setText(leftBottom2);
      } else {
        tvLeft2.setVisibility(View.GONE);
      }

      String rightBottom2 = mCarouselItems.get(rightPosition).getRightBottom();

      if (!TextUtils.isEmpty(rightBottom2)) {
        tvRight2.setText(rightBottom2);
      } else {
        tvRight2.setVisibility(View.GONE);
      }
      tvItemType2.setText(mCarouselItems.get(rightPosition).titleCaps);
      tvItemName2.setText(mCarouselItems.get(rightPosition).titleName);
      tvItemPrice2.setText(mCarouselItems.get(rightPosition).price);
      ivItem2.setImageUrl(mCarouselItems.get(rightPosition).imgUrl, mImageLoader);
    } else {
      tvLeft2.setVisibility(View.GONE);
      tvRight2.setVisibility(View.GONE);
      tvItemType2.setVisibility(View.GONE);
      tvItemName2.setVisibility(View.GONE);
      tvItemPrice2.setVisibility(View.GONE);
      ivItem2.setVisibility(View.GONE);
    }

    tvLeft1.setOnClickListener(new View.OnClickListener() {
      @Override public void onClick(View v) {
        getListener().onCarouselItemSelect(position);
      }
    });

    tvLeft2.setOnClickListener(new View.OnClickListener() {
      @Override public void onClick(View v) {
        getListener().onCarouselItemSelect(position);
      }
    });
    container.addView(v);

    return v;
  }

  @Override public void destroyItem(ViewGroup container, int position, Object object) {
    container.removeView((View) object);
  }

  public void setCarouselData(ArrayList<CarouselItem> carouselData) {
    mCarouselItems.addAll(carouselData);
    notifyDataSetChanged();
  }

  public interface OnCarouselItemSelected {
    void onCarouselItemSelect(int position);
  }

  private OnCarouselItemSelected getListener() {
    if (mListener != null) return mListener;

    if (mOnCarouselItemSelectedWeakReference != null) {
      mListener = mOnCarouselItemSelectedWeakReference.get();
    }

    return mListener;
  }
}
