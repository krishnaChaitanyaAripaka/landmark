package assignment.com.landmark.landmarkassignment.connection;

import android.os.AsyncTask;
import android.text.TextUtils;
import assignment.com.landmark.landmarkassignment.model.CarouselItem;
import assignment.com.landmark.landmarkassignment.model.CarouselModel;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/**
 * Created by chaitanya.ak on 13/09/16.
 */
public class ParseHTML {
  private static final String BASE_URL = "http://www.landmarkshops.com";
  private static final String BADGE_LEFT_BOTTOM_GREEN_NEW = "badge leftbottom green-new";
  private static final String BADGE_LEFT_BOTTOM_GREEN_BEST_BUY = "badge leftbottom green-bestbuy";
  private static final String BADGE_LEFT_BOTTOM_BLUE_ONLINE = "badge leftbottom blue-online";
  private static final String BADGE_LEFT_BOTTOM_RED = "badge leftbottom red-sale";
  private static final String BADGE_LEFT_BOTTOM_BLUE_SEASON = "badge leftbottom blue-season";
  private static final String BADGE_RIGHT_BOTTOM_RED_SALE = "badge rightbottom red-sale";
  private static final String BADGE_RIGHT_BOTTOM_PINK_PERCENTAGE =
      "badge rightbottom pink-percentage";
  private static final String BADGE_TILE_UPPERCASE = "title text-uppercase";
  private static final String BADGE_TILE = "title";

  private final WeakReference<OnDataLoadListener> mOnDataLoadListenerWeakReference;

  public ParseHTML(WeakReference<OnDataLoadListener> onDataLoadListenerWeakReference) {
    mOnDataLoadListenerWeakReference = onDataLoadListenerWeakReference;
  }

  private class ParseURL extends AsyncTask<Void, Void, ArrayList<CarouselModel>> {

    @Override protected ArrayList<CarouselModel> doInBackground(Void... params) {
      try {
        return getDataObject(Jsoup.connect(BASE_URL).get());
      } catch (IOException e) {
        e.printStackTrace();
      }
      return null;
    }

    private ArrayList<CarouselModel> getDataObject(Document doc) {
      Elements elements = doc.select("div");

      if (elements.size() == 0) return null;

      ArrayList<CarouselModel> carouselModels = new ArrayList<>();

      for (Element element : elements) {
        if (element.hasClass("block")) {
          Elements children = element.children();
          if (children.size() > 1) {
            CarouselModel carouselModel = new CarouselModel();
            carouselModel.header = children.get(0).text();
            carouselModel.mCarouselItems = new ArrayList<>();
            Elements items = children.get(1).getElementsByClass("products").get(0).children();

            for (int j = 0; j < items.size(); j++) {
              CarouselItem carouselItem = new CarouselItem();
              Element elementData = items.get(j);
              carouselItem.imgUrl = elementData.select("img").get(0).absUrl("src");
              Elements spans = elementData.getElementsByTag("span");
              Elements del = elementData.getElementsByTag("del");

              for (int k = 0; k < spans.size(); k++) {
                String className = spans.get(k).className();
                String classValue = spans.get(k).text();

                String idValue = spans.get(k).select("span[itemprop=price]").text();
                String delValue = del.text();

                if (className != null) {
                  switch (className) {
                    case BADGE_LEFT_BOTTOM_GREEN_NEW:
                      carouselItem.badgeLeftBottomGreenNew = classValue;
                      break;
                    case BADGE_LEFT_BOTTOM_GREEN_BEST_BUY:
                      carouselItem.badgeLeftBottomGreenBestBuy = classValue;
                      break;
                    case BADGE_LEFT_BOTTOM_BLUE_ONLINE:
                      carouselItem.badgeLeftBottomBlueOnline = classValue;
                      break;
                    case BADGE_LEFT_BOTTOM_BLUE_SEASON:
                      carouselItem.badgeLeftBottomBlueSeason = classValue;
                      break;
                    case BADGE_LEFT_BOTTOM_RED:
                      carouselItem.badgeLeftBottomRed = classValue;
                      break;
                    case BADGE_RIGHT_BOTTOM_RED_SALE:
                      carouselItem.badgeRightBottomRedSale = classValue;
                      break;
                    case BADGE_RIGHT_BOTTOM_PINK_PERCENTAGE:
                      carouselItem.badgeRightBottomPinkPercentage = classValue;
                      break;
                    case BADGE_TILE_UPPERCASE:
                      carouselItem.titleCaps = classValue;
                      break;
                    case BADGE_TILE:
                      carouselItem.titleName = classValue;
                      break;
                  }
                }

                if (!TextUtils.isEmpty(idValue)) {
                  carouselItem.price = idValue;
                }

                if (!TextUtils.isEmpty(delValue)) {
                  carouselItem.actualPrice = delValue;
                }
              }

              carouselModel.mCarouselItems.add(carouselItem);
            }

            carouselModels.add(carouselModel);
          }
        }
      }
      return carouselModels;
    }

    @Override protected void onPostExecute(ArrayList<CarouselModel> carouselModels) {
      super.onPostExecute(carouselModels);
      if (mOnDataLoadListenerWeakReference != null) {
        OnDataLoadListener listener = mOnDataLoadListenerWeakReference.get();
        if (listener != null) {
          listener.onDataLoad(carouselModels);
        }
      }
    }
  }

  public void execute() {
    new ParseURL().execute();
  }

  public interface OnDataLoadListener {
    void onDataLoad(ArrayList<CarouselModel> carouselModels);
  }
}
