package assignment.com.landmark.landmarkassignment;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import assignment.com.landmark.landmarkassignment.adapter.CarouselAdapter;
import assignment.com.landmark.landmarkassignment.connection.ParseHTML;
import assignment.com.landmark.landmarkassignment.model.CarouselModel;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

public class CarouselActivity extends AppCompatActivity
    implements ParseHTML.OnDataLoadListener {

  private RecyclerView mRecyclerView;
  private ArrayList<CarouselModel> mCarouselModels;
  private CarouselAdapter mHeaderAdapter;

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_carousel);

    mRecyclerView = (RecyclerView) findViewById(R.id.recyclerView);
    mHeaderAdapter = new CarouselAdapter(this);
    mRecyclerView.setAdapter(mHeaderAdapter);
    mRecyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));

    ParseHTML parseHTML = new ParseHTML(new WeakReference<ParseHTML.OnDataLoadListener>(this));
    parseHTML.execute();
  }

  @Override public void onDataLoad(ArrayList<CarouselModel> carouselModels) {
    mCarouselModels = carouselModels;
    mHeaderAdapter.setData(mCarouselModels);
  }
}
