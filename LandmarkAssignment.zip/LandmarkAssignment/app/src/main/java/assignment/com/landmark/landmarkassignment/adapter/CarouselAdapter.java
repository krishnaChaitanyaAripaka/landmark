package assignment.com.landmark.landmarkassignment.adapter;

import android.content.Context;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import assignment.com.landmark.landmarkassignment.R;
import assignment.com.landmark.landmarkassignment.model.CarouselModel;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

/**
 * Created by chaitanya.ak on 13/09/16.
 */
public class CarouselAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>
    implements CarouselPageAdapter.OnCarouselItemSelected {

  private final ArrayList<CarouselModel> mCarouselModels;
  private final Context mContext;
  private final LayoutInflater mInflater;

  public CarouselAdapter(Context context) {
    mContext = context;
    mInflater = LayoutInflater.from(mContext);
    mCarouselModels = new ArrayList<>();
  }

  @Override public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {

    View v = mInflater.inflate(R.layout.header_cell, viewGroup, false);

    return new ItemsViewHolder(v);
  }

  @Override public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, int i) {

    ItemsViewHolder itemsViewHolder = (ItemsViewHolder) viewHolder;
    CarouselPageAdapter adapter = new CarouselPageAdapter(mContext,
        new WeakReference<CarouselPageAdapter.OnCarouselItemSelected>(this));
    adapter.setCarouselData(mCarouselModels.get(i).mCarouselItems);
    itemsViewHolder.getViewPager().setAdapter(adapter);
  }

  @Override public int getItemViewType(int position) {
    return position;
  }

  @Override public int getItemCount() {
    return mCarouselModels.size();
  }

  @Override public void onCarouselItemSelect(int position) {
    Toast.makeText(mContext, mCarouselModels.get(position).header, Toast.LENGTH_SHORT).show();
  }

  public void setData(ArrayList<CarouselModel> carouselModels) {
    mCarouselModels.addAll(carouselModels);
    notifyDataSetChanged();
  }

  class ItemsViewHolder extends RecyclerView.ViewHolder {

    ViewPager mViewPager;

    public ItemsViewHolder(View v) {
      super(v);
      mViewPager = (ViewPager) v.findViewById(R.id.viewPager);
    }

    public ViewPager getViewPager() {
      return mViewPager;
    }
  }
}
