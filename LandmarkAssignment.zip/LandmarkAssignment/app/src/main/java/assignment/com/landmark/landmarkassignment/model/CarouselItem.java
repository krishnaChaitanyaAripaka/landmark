package assignment.com.landmark.landmarkassignment.model;

import android.text.TextUtils;

/**
 * Created by chaitanya.ak on 13/09/16.
 */
public class CarouselItem {
  public String imgUrl;
  public String badgeLeftBottomGreenNew;
  public String badgeLeftBottomGreenBestBuy;
  public String badgeLeftBottomBlueOnline;
  public String badgeLeftBottomBlueSeason;
  public String badgeLeftBottomRed;
  public String badgeRightBottomRedSale;
  public String badgeRightBottomPinkPercentage;
  public String titleCaps;
  public String titleName;
  public String price;
  public String actualPrice;

  public String getLeftBottom() {
    if (notEmpty(badgeLeftBottomGreenNew)) {
      return badgeLeftBottomGreenNew;
    } else if (notEmpty(badgeLeftBottomGreenBestBuy)) {
      return badgeLeftBottomGreenBestBuy;
    } else if (notEmpty(badgeLeftBottomBlueOnline)) {
      return badgeLeftBottomBlueOnline;
    } else if (notEmpty(badgeLeftBottomBlueSeason)) {
      return badgeLeftBottomBlueSeason;
    } else if (notEmpty(badgeLeftBottomRed)) {
      return badgeLeftBottomRed;
    } else {
      return null;
    }
  }

  public String getRightBottom() {
    if (notEmpty(badgeRightBottomRedSale)) {
      return badgeRightBottomRedSale;
    } else if (notEmpty(badgeRightBottomPinkPercentage)) {
      return badgeRightBottomPinkPercentage;
    } else {
      return null;
    }
  }

  private boolean notEmpty(String value) {
    return !TextUtils.isEmpty(value);
  }
}
